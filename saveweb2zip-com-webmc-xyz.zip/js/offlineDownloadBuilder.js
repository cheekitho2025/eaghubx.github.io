async function buildOfflineDownload(id, jspi) {
  const v = findVersion(id);
  const n = new Date();
  const p = `api/g/${v.uuid}/`;

  let [i, b, o, h, c, a, s] = await Promise.all([
    fetch(`assets/img/icons/games/${v.uuid}.${v.icon_ext || 'png'}`).then(r => r.arrayBuffer()),
    fetch('assets/meta/OfflineDownloadTemplate.txt').then(r => r.text()),
    fetch('assets/js/opts.js').then(r => r.text()),
    fetch('api/script/b.js').then(r => r.text()),
    fetch(p + (!window.webmcIsJSPI ? 'classes' : 'bootstrap') + '.js').then(r => r.text()),
    fetch(p + 'assets' + (!window.webmcIsJSPI ? '.epk' : '.epw')).then(r => r.arrayBuffer()),
    fetch('assets/css/game.css').then(r => r.text())
  ]);

  b = b.replace('{origin}', window.location.origin)
    .replace('{version}', v.name || v.version)
    .replace('{date}', `${n.toLocaleDateString()} at ${n.toLocaleTimeString()}`)
    .replace('{icon', webmcEncodeOfflineDownloadChars(i))
    .replace('{loc}', JSON.stringify({
        protocol: window.location.protocol,
        host: window.location.host,
        hostname: window.location.hostname,
        pathname: window.location.pathname
      }))
    .replace('{jspi}', jspi)
    .replace('{webmc}', webmcEncodeOfflineDownloadChars(h))
    .replace('{opts}', webmcEncodeOfflineDownloadChars(o))
    .replace('{classes}', webmcEncodeOfflineDownloadChars(c))
    .replace('{assets}', webmcEncodeOfflineDownloadChars(a))
    .replace('{css}', s);

  const blob = new Blob([b], { type: 'text/html' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = `${v.name || 'WebMC_Offline'}_${jspi ? 'JSPI' : 'JS'}.html`;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

function webmcEncodeOfflineDownloadChars(data) {
  if (data instanceof ArrayBuffer) {
    let bin = '';
    const bytes = new Uint8Array(data);
    for (let i = 0; i < bytes.length; i++) bin += String.fromCharCode(bytes[i]);
    return btoa(bin);
  } else {
    return btoa(unescape(encodeURIComponent(data)));
  }
}