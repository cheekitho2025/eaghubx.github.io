const data = {
  loader: {
    main: null,
    game: null
  },
  game: null,
  launched: {
    status: false,
    id: null,
    jspi: false
  },
  relaunching: null,
  gameButton: null,
  data: [],
  custom: {
    stored: [],
    data: []
  },
  frame: null,
  console: null,
  jspiSupported: false,
  iconBase: 'assets/img/icons/games/',
  consoleLogs: [],
  dropdown: {
    open: false,
    elm: null,
    selected: [null, false]
  },
  btns: {
    fs: {
      elm: null,
      active: false,
      svg: [
        'M0 0h1v1h-1zM1 0h1v1h-1zM2 0h1v1h-1z M5 0h1v1h-1zM6 0h1v1h-1zM7 0h1v1h-1z M0 1h1v1h-1zM7 1h1v1h-1z M0 2h1v1h-1zM7 2h1v1h-1z M0 5h1v1h-1zM7 5h1v1h-1z M0 6h1v1h-1zM7 6h1v1h-1z M0 7h1v1h-1zM1 7h1v1h-1zM2 7h1v1h-1z M5 7h1v1h-1zM6 7h1v1h-1zM7 7h1v1h-1z',
        'M2 0h1v1h-1zM5 0h1v1h-1z M2 1h1v1h-1zM5 1h1v1h-1z M0 2h1v1h-1zM1 2h1v1h-1zM2 2h1v1h-1zM5 2h1v1h-1zM6 2h1v1h-1zM7 2h1v1h-1z M0 5h1v1h-1zM1 5h1v1h-1zM2 5h1v1h-1zM5 5h1v1h-1zM6 5h1v1h-1zM7 5h1v1h-1z M2 6h1v1h-1zM5 6h1v1h-1z M2 7h1v1h-1zM5 7h1v1h-1z'
      ]
    }
  }
};

let q = window.location.search;

document.addEventListener('DOMContentLoaded', async function () {
  loadSettings();
  if (typeof q === 'string' && q[0] === '?' && typeof window.URLSearchParams !== 'undefined') {
    q = new window.URLSearchParams(q);
    const s = q.get('settings');
    if (s) {
      try {
        const sp = JSON.parse(s);
        settings = merge(settings, sp);
        history.replaceState('', document.title, window.location.pathname + window.location.hash);
      } catch {}
    }
  }
  initSettings();
  if (settings.background.value && settings.background.value != '') {
    document.querySelector('.bg').style.setProperty(
      'background-image',
            `url("${settings.background.value}")`,
            'important'
    );
  }
  data.loader.main = document.querySelector('#loadermain');
  data.loader.game = document.querySelector('#loadergame');
  data.gameButton = document.querySelector('.game-button');
  data.dropdown.elm = document.querySelector('.dropdown');
  data.console = document.querySelector('.section.console');
  // data.frame = document.querySelector(".game_frame");
  data.jspiSupported = (typeof WebAssembly !== 'undefined') && (typeof WebAssembly.Suspending !== 'undefined');
  await fetch('api').then(res => res.json()).then(res => {
    document.querySelector('.sidebar-discord').setAttribute('href', res.discord);
    document.querySelector('.version').innerHTML += `${res.version}+s${res.server.split('/').pop()}`;
  });
  await fetch('api/data').then(res => res.json()).then(res => {
    data.data = res;
    buildDropdown();
  });
  let hash = window.location.hash;
  if (hash.startsWith('#/')) {
    hash = hash.substring(2);
    if (hash.startsWith('s/')) {
      navigateSidebar(hash.substring(2), false);
    } else if (hash.startsWith('t/')) {
      document.querySelector('.title').style.animationDuration = '0s';
      navigateTopbar(hash.substring(2), false);
    } else if (hash.startsWith('g/')) {
      let vi = hash.substring(2);
      let js = false;
      let jspi = false;
      if (vi.endsWith('/js')) {
        vi = vi.slice(0, -3);
        js = true;
        jspi = false;
      } else if (vi.endsWith('/jspi')) {
        vi = vi.slice(0, -5);
        js = false;
        jspi = true;
      }
      const v = findVersion(vi);
      return launchGame(v, !js && (jspi || (v.jspi && data.jspiSupported) || v.forceJSPI), true);
    } else if (hash.startsWith('m/')) {
      let vn = hash.substring(2);
      let js = false;
      let jspi = false;
      if (vn.endsWith('-js')) {
        vn = vn.slice(0, -3);
        js = true;
        jspi = false;
      } else if (vn.endsWith('-jspi')) {
        vn = vn.slice(0, -5);
        js = false;
        jspi = true;
      }
      const v = findVersionByName(vn);
      return launchGame(v, !js && (jspi || (v.jspi && data.jspiSupported) || v.forceJSPI), true);
    } else {
      navigateRoot();
    }
  }
  await fetchChangelog();
  buildNavbar();
  data.gameButton.addEventListener('click', () => {
    stopGame();
    if (!data.launched.status) {
      launchGame(data.dropdown.selected[0], data.dropdown.selected[1], false);
    }
    data.launched.status = !data.launched.status;
    toggleButton();
  });
  document.querySelector('.dropdown-selector').addEventListener('click', toggleDropdown);
  const sel = localStorage.getItem('selectedVersion');
  if (sel) {
    selectVersion(JSON.parse(sel)[0], JSON.parse(sel)[1]);
  } else {
    selectVersion(data.data.default, data.jspiSupported);
  }
  document.addEventListener('click', (event) => {
    const dropdown = data.dropdown.elm;
    const toggleButton = document.querySelector('.dropdown-selector');

    if (data.dropdown.open && !dropdown.contains(event.target) && !toggleButton.contains(event.target)) {
      toggleDropdown();
    }
  });
  document.querySelectorAll('.topbar .topbar-buttons a').forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.preventDefault();
      navigateTopbar(btn.id.substring(7), false);
    });
  });
  document.querySelector('.section.installations .newInstall').addEventListener('click', () => {
    document.querySelector('.installCreation').style.display = 'flex';
  });
  document.querySelectorAll('.installCreation input[type="text"]').forEach(elm => {
    elm.value = elm.dataset.value;
  });
  document.querySelector('.installCreation input[type="submit"]').addEventListener('click', (e) => {
    e.preventDefault();
    const form = document.querySelector('.installCreation');
    const inputs = form.querySelectorAll('input:not([type="submit"])');
    let f = true;

    for (const input of inputs) {
      if (!input.value.trim()) {
        f = false;
        input.classList.add('unfilled');
        break;
      } else {
        input.classList.remove('unfilled');
      }
    }

    if (f) {
      addCustomVersion({
        id: crypto.randomUUID(),
        name: form.querySelector('#name').value,
        version: form.querySelector('#ver').value,
        url: form.querySelector('#url').value,
        jspi: false
      });
      refreshInstalls();
    } else {
      form.querySelector('.unfilled').focus();
      notify('Error', 'Please fill out all required fields.', 2000);
    }
  });
  const ws = window.connectSocket(window.socketBase + 'api/playerCounter', (e) => {
    const msg = JSON.parse(e.data);
    if (msg.type == 'ping') {
      ws.send(JSON.stringify({ type: 'pong', timestamp: Date.now() }));
    } else if (msg.type == 'init' || msg.type == 'update') {
      const players = settings.globalPlayerCount.value ? msg.global + msg.local : msg.local;
      document.querySelector('.status #playerCount #count').textContent = players.toLocaleString();
    }
  });
  function updateClock () {
    document.querySelector('.status #time').textContent = window.getTime();
  }
  updateClock();
  setTimeout(() => {
    updateClock();
    setInterval(updateClock, 1000);
  }, 1000 - new Date().getMilliseconds());
  localStorage.setItem('seen_about', 1);
  localStorage.setItem('disclaimer_accepted', 1);
  // data.custom.stored = localStorage.getItem("customVersions");
  // refreshInstalls();
});

window.addEventListener('load', function () {
  data.loader.main.style.display = 'none';
  document.querySelector('.title').style.display = 'block';
});

window.addEventListener('keydown', function (e) {
  if (e.repeat) return;
  if (e.keyCode === 27 && data.dropdown.open) {
    toggleDropdown();
  } else if (e.altKey && e.keyCode === 70) {
    flip();
  }
});

window.addEventListener('message', (e) => {
  if (e.data?.type === 'popup-closed' && e.data.token === data.relaunching) {
    stopGame();
    data.launched.status = false;
    toggleButton();
    data.relaunching = null;
  } else if (e.data?.type === 'console') {
    const id = e.data.id;
    const msg = e.data.message;
    const type = e.data.console;
    if (data.consoleLogs.includes(id)) {
      return;
    } else {
      data.consoleLogs.push(id);
    }
    console[type != 'success' ? type : 'log'](msg);
    log(msg, type, id, false);
  }
});

function log (m, t, id = crypto.randomUUID(), launcher) {
  const elm = document.createElement('div');
  elm.classList.add(t);
  elm.dataset.id = id;
  elm.innerText = m;
  if (launcher) elm.classList.add('launcher');
  const maxloglength = 100;
  if (data.consoleLogs.length > maxloglength || data.console.children.length > maxloglength) {
    data.consoleLogs.shift();
    data.console.removeChild(data.console.children[0]);
  }
  if (data.console.classList.contains('empty')) {
    data.console.classList.remove('empty');
    data.console.innerHTML = '';
  }
  data.console.appendChild(elm);
  data.console.scrollTop = data.console.scrollHeight;
}

function launchGame (v, jspi = false, inline = false) {
  const v1 = v.uuid ? v : findVersion(v);
  const basePath = `api/g/${v1.uuid}/`;
  const relaunchToken = crypto.randomUUID();
  data.relaunching = relaunchToken;
  let extrascripts = '';
  let wispcraft = '';
  if (v1.extrascripts) extrascripts = v1.extrascripts.map(s => `<script src="${basePath}${s}"></script>`).join('\n');
  if (v1.wispcraft && settings.wispcraft.value) wispcraft = `<script src="assets/js/wispcraft/wispcraft-${v1.wispcraft}.js"></script>`;
  let html = '';
  if (!v1.customIndex) {
    html = `
    <!DOCTYPE html>
    <html>
      <head>
      <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0" />
      <link rel="stylesheet" href="assets/css/loader.css">
      <link rel="stylesheet" href="assets/css/game.css">
      <script>
        window.webmcBasePath = "${basePath}";
        window.webmcClientId = "${v}";
        window.webmcIsNodeJS = false;
        window.webmcIsOfflineDownload = false;
        window.webmcIsJSPI = ${jspi};
        window.webmcIsEagsMod = ${v1.eags};
        window.webmcRealLocation = ${JSON.stringify({
          protocol: window.location.protocol,
          host: window.location.host,
          hostname: window.location.hostname,
          pathname: window.location.pathname
        })};
        Object.defineProperty(window, "onbeforeunload", {
          configurable: false,
          enumerable: true,
          get() {
            return function(e) {
              e.returnValue = "";
              window.opener?.postMessage({ type: "popup-closed", token: "${relaunchToken}" }, "*");
              return "";
            };
          },
          set() {}
        });

        window.addEventListener("beforeunload", function(e) {
          const fn = window.onbeforeunload;
          if (typeof fn === "function") fn(e);
        });

        var _console = console;
        console = {
          ...console,
          log: function() {
            _console.log.apply(_console, arguments);
            window.opener?.postMessage({ type: "console", console: "log", id: crypto.randomUUID(), message: arguments[0] }, "*");
          },
          warn: function() {
            _console.warn.apply(_console, arguments);
            window.opener?.postMessage({ type: "console", console: "warn", id: crypto.randomUUID(), message: arguments[0] }, "*");
          },
          error: function() {
            _console.error.apply(_console, arguments);
            window.opener?.postMessage({ type: "console", console: "error", id: crypto.randomUUID(), message: arguments[0] }, "*");
          },
          info: function() {
            _console.info.apply(_console, arguments);
            window.opener?.postMessage({ type: "console", console: "info", id: crypto.randomUUID(), message: arguments[0] }, "*");
          },
          success: function() {
            _console.log.apply(_console, arguments);
            window.opener?.postMessage({ type: "console", console: "success", id: crypto.randomUUID(), message: arguments[0] }, "*");
          }
        };
        window.onerror = function(message, source, lineno, colno, error) {
          window.parent.postMessage({
            type: "console",
            console: "error",
            id: crypto.randomUUID(),
            message: \`[Uncaught Error] \${message} at \${source}:\${lineno}:\${colno}\`
          }, "*");
        };

        window.onunhandledrejection = function(event) {
          window.parent.postMessage({
            type: "console",
            console: "error",
            id: crypto.randomUUID(),
            message: \`[Unhandled Promise] \$\{event.reason}\`
          }, "*");
        };
      </script>
      <script src="assets/js/global.js" type="module"></script>
      <script src="assets/js/opts.js" type="module"></script>
      <script src="api/script/b.js"></script>
      ${extrascripts}
      ${wispcraft}
      <script src="api/g/${v1.uuid}/${!jspi && !v1.eags ? 'classes' : 'bootstrap'}.js"></script>
      <script>
        window.addEventListener("load", () => {
          console.log("Starting game...");
          window.focus();
          if (typeof main === "function") {
            webmcInitClientOpts();
            main();
            window.connectPlayerCounter();
          } else {
            console.error("Failed to start game!");
            window.close();
          }
        });
        window.addEventListener("blur", () => {
          setTimeout(() => {
            window.focus();
          }, 10);
        });
      </script>
      </head>
      <body class="loader">
        <div id="game_frame" fullscreen></div>
      </body>
    </html>
        `;
  } else {
    html = `
    <!DOCTYPE html>
    <html>
      <head>
      <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0" />
      <link rel="stylesheet" href="assets/css/loader.css">
      <link rel="stylesheet" href="assets/css/game.css">
      <script>
        window.webmcBasePath = "${basePath}";
        window.webmcClientId = "${v}";
        window.webmcIsNodeJS = false;
        window.webmcIsOfflineDownload = false;
        window.webmcIsJSPI = ${jspi};
        window.webmcIsEagsMod = ${v1.eags};
        window.webmcRealLocation = ${JSON.stringify({
          protocol: window.location.protocol,
          host: window.location.host,
          hostname: window.location.hostname,
          pathname: window.location.pathname
        })};
        Object.defineProperty(window, "onbeforeunload", {
          configurable: false,
          enumerable: true,
          get() {
            return function(e) {
              e.returnValue = "";
              window.opener?.postMessage({ type: "popup-closed", token: "${relaunchToken}" }, "*");
              return "";
            };
          },
          set() {}
        });

        window.addEventListener("beforeunload", function(e) {
          const fn = window.onbeforeunload;
          if (typeof fn === "function") fn(e);
        });

        var _console = console;
        console = {
          ...console,
          log: function() {
            _console.log.apply(_console, arguments);
            window.opener?.postMessage({ type: "console", console: "log", id: crypto.randomUUID(), message: arguments[0] }, "*");
          },
          warn: function() {
            _console.warn.apply(_console, arguments);
            window.opener?.postMessage({ type: "console", console: "warn", id: crypto.randomUUID(), message: arguments[0] }, "*");
          },
          error: function() {
            _console.error.apply(_console, arguments);
            window.opener?.postMessage({ type: "console", console: "error", id: crypto.randomUUID(), message: arguments[0] }, "*");
          },
          info: function() {
            _console.info.apply(_console, arguments);
            window.opener?.postMessage({ type: "console", console: "info", id: crypto.randomUUID(), message: arguments[0] }, "*");
          },
          success: function() {
            _console.log.apply(_console, arguments);
            window.opener?.postMessage({ type: "console", console: "success", id: crypto.randomUUID(), message: arguments[0] }, "*");
          }
        };

        window.onerror = function(message, source, lineno, colno, error) {
          window.parent.postMessage({
              type: "console",
              console: "error",
              id: crypto.randomUUID(),
              message: \`[Uncaught Error] \${message} at \${source}:\${lineno}:\${colno}\`
          }, "*");
        };

        window.onunhandledrejection = function(event) {
          window.parent.postMessage({
            type: "console",
            console: "error",
            id: crypto.randomUUID(),
            message: \`[Unhandled Promise] \$\{event.reason}\`
          }, "*");
        };
      </script>
      <script src="assets/js/global.js" type="module"></script>
      <script src="api/script/b.js"></script>
      ${extrascripts}
      <script>
        window.SharedArrayBuffer = ${window.SharedArrayBuffer};
        window.addEventListener("load", () => {
          console.log("Starting game...");
          document.getElementById("game_frame").contentWindow.focus();
          window.connectPlayerCounter();
        });
        window.addEventListener("blur", () => {
          setTimeout(() => {
            document.getElementById("game_frame").contentWindow.focus();
          }, 10);
        });
      </script>
      </head>
      <body class="loader">
        <iframe src="${basePath}index.html" id="game_frame" fullscreen>
      </body>
    </html>
        `;
  }
  if (inline) {
    const doc = window.document;
    doc.open();
    doc.write(html);
    doc.close();
    doc.title = v1.oname || v1.name;
    doc.querySelectorAll('link[rel~="icon"]').forEach(el => el.remove());
    const icon = doc.createElement('link');
    icon.rel = 'icon';
    icon.href = `${data.iconBase}${v.uuid || '00000000-0000-0000-0000-000000000000'}.${v.icon_ext || 'png'}`;
    const sicon = icon.cloneNode();
    sicon.rel = 'shortcut icon';
    doc.head.appendChild(icon);
    doc.head.appendChild(sicon);
    return;
  }
  /* data.loader.game.style.display = "flex";
    data.frame.srcdoc = html.replaceAll("\n", "");
    data.frame.classList.add("active"); */
  const h = window.outerHeight * 0.75;
  const w = window.outerWidth * 0.85;
  const y = window.screenY + (window.outerHeight - h) / 2;
  const x = window.screenX + (window.outerWidth - w) / 2;
  const params = `toolbar=no, location=no, directories=no, status=no, menubar=no, scrollbars=no, copyhistory=no, width=${w}, height=${h}, top=${y}, left=${x}`;
  data.game = window.open('about:blank', '_webmcgame', !settings.popupTab.value ? params : '');
  const doc = data.game.window.document;
  doc.open();
  doc.write(html);
  doc.close();
  const suffix = data.jspiSupported && v1.jspi && !v1.forceJSPI ? (jspi ? ' JSPI' : '') : '';
  data.game.window.document.title = v1.oname || v1.name; // + suffix;
  document.documentElement.classList.add('game-active');
  data.launched.id = v1.uuid;
  data.launched.jspi = jspi;
  log(`[WebMC]: Launching ${(v1.version || v1.oname || v1.name) + suffix}`, 'success', null, true);
  if (settings.gameNotifications.value) {
    notify('Game Notifications', `Launching ${(v1.oname || v1.name) + suffix}`, 3000);
  }
  if (settings.showGameLog.value) {
    navigateTopbar('console', false);
  }
}

function stopGame () {
  /* data.loader.game.style.display = "none";
    data.frame.classList.remove("active");
    data.frame.srcdoc = ""; */
  if (data.game) {
    data.game.close();
    data.game = null;
  }
  data.launched.id = null;
  data.launched.jspi = false;
  document.documentElement.classList.remove('game-active');
}

function buildNavbar () {
  document.querySelectorAll('.sidebar .sidebar-item').forEach(e => {
    e.addEventListener('click', function () {
      if (!e.dataset.href) {
        navigateSidebar(e.dataset.id, false);
      } else {
        window.open(e.dataset.href, '_blank');
      }
    });
  });
}

function buildDropdown () {
  const data1 = data.data;
  let latest = data1.data.find(d => d.uuid === data1.latest);
  const defaultVer = data1.data.find(d => d.uuid === data1.default);
  const sponsored = data1.data.filter(d => d.sponsored >= 1).sort((a, b) => a.sponsored - b.sponsored);
  data1.data = data1.data.filter(d => !(d.sponsored >= 1));
  for (let i = 0; i < sponsored.length; i++) addDropdown(sponsored[i]);
  latest = {
    ...latest,
    oname: latest.name,
    version: latest.name,
    name: `Latest${((data.jspiSupported && !settings.showJSClients.value) || !data.jspiSupported) ? ' Release' : ''}`
  };
  addDropdown(latest);
  data.latest = latest;
  data.default = defaultVer;
  data1.data = data1.data.filter(d => d.uuid !== data1.latest);
  for (let i = 0; i < data1.data.length; i++) addDropdown(data1.data[i]);
  data1.data.unshift(...sponsored);
  data1.data.unshift(latest);
}

function addDropdown (d) {
  function addDropdown1 (ver1, name, id, jspi = false, custom = false, sponsored) {
    const elm1 = document.createElement('div');
    elm1.classList.add('dropdown-version');
    elm1.addEventListener('click', function () {
      toggleDropdown();
      if (data.dropdown.selected[0] === id && data.dropdown.selected[1] === jspi) return;
      else if (data.launched.id === id && data.launched.jspi === jspi) {
        data.gameButton.classList.remove('relaunch');
        data.gameButton.classList.remove('play');
        data.gameButton.classList.add('stop');
        data.gameButton.textContent = 'STOP';
        data.launched.status = true;
        return;
      }
      selectVersion(id, jspi);
    });

    if (custom) elm1.classList.add('custom-install');

    const elm2 = document.createElement('img');
    elm2.classList.add('dropdown-icon');
    elm2.draggable = false;
    elm2.src = `${data.iconBase}${!custom ? id : '00000000-0000-0000-0000-000000000000'}.${d.icon_ext || 'png'}`;

    const elm3 = document.createElement('div');
    elm3.classList.add('version-info');

    const elm4 = document.createElement('a');
    elm4.textContent = name;
    if (sponsored) elm4.classList.add('sponsored');

    const elm5 = document.createElement('a');
    elm5.textContent = ver1;

    elm3.appendChild(elm4);
    elm3.appendChild(elm5);
    elm1.appendChild(elm2);
    elm1.appendChild(elm3);
    document.querySelector('.dropdown').appendChild(elm1);
  }

  const v = d.version || d.name;
  const jspi = d.jspi && data.jspiSupported && !d.forceJSPI;
  const sponsored = d.sponsored >= 1;

  if (jspi) addDropdown1(`${v}-jspi`, `${d.name}${settings.showJSClients.value ? ' (JSPI)' : ''}`, d.uuid, true, d.custom || false, sponsored);
  if (!jspi || settings.showJSClients.value) addDropdown1(`${v}-js`, `${d.name}${jspi ? ' (JS)' : ''}`, d.uuid, false, d.custom || false, sponsored);
}

function toggleButton (forceText = null) {
  const btn = data.gameButton;
  btn.classList.remove('play', 'stop', 'relaunch');

  if (forceText === 'RELAUNCH') {
    btn.classList.add('relaunch');
    btn.innerHTML = 'RELAUNCH';
    return;
  }

  if (data.launched.status) {
    btn.classList.add('stop');
    btn.innerHTML = 'STOP';
  } else {
    btn.classList.add('play');
    btn.innerHTML = 'PLAY';
  }
}

function toggleDropdown () {
  data.dropdown.elm.style.display = (data.dropdown.elm.style.display === 'none' || !data.dropdown.elm.style.display) ? 'flex' : 'none';
  data.dropdown.open = !data.dropdown.open;
}

function findVersion (id) {
  return data.data.data.concat(data.custom).find(d => d.uuid === id) || data.default;
}

function findVersionByName (name) {
  return data.data.data.concat(data.custom).find(d => (d.version === name || d.oname === name || d.name === name)) || data.default;
}

function selectVersion (id, jspi = false) {
  const v = findVersion(id);
  const sel = document.querySelector('.dropdown-selector');
  localStorage.setItem('selectedVersion', JSON.stringify([id, jspi]));
  sel.querySelector('.version-info #title').textContent = `${v.name}${data.jspiSupported && v.jspi && settings.showJSClients.value && !v.forceJSPI ? (jspi ? ' (JSPI)' : ' (JS)') : ''}`;
  sel.querySelector('.version-info #version').textContent = `${v.version || v.name}${!v.forceJSPI ? (jspi ? '-jspi' : '-js') : ''}`; // ${data.jspiSupported && v.jspi ? (jspi ? "-jspi" : "-js") : ""}`;
  sel.querySelector('.dropdown-selector-icon').src = `${data.iconBase}${id}.${v.icon_ext || 'png'}`;
  data.dropdown.selected[0] = v.uuid;
  data.dropdown.selected[1] = jspi;
  if (data.launched.status) {
    data.launched.status = !data.launched.status;
    data.gameButton.classList.remove('play');
    data.gameButton.classList.remove('stop');
    data.gameButton.classList.add('relaunch');
    data.gameButton.innerHTML = 'RELAUNCH';
  }
}

function flip (elm = document.body) {
  elm.classList.add('flip');
  if (elm.dataset.flipped === 'true') {
    elm.style.transform = 'rotateX(0deg) rotateY(0deg)';
    elm.dataset.flipped = 'false';
  } else {
    elm.style.transform = 'rotateX(180deg) rotateY(180deg)';
    elm.dataset.flipped = 'true';
  }
}

function navigateSidebar (l, r) {
  document.querySelectorAll('.sidebar .sidebar-item').forEach(e => {
    e.classList.remove('active');
  });
  document.querySelector(`.sidebar .sidebar-${l}`).classList.add('active');
  document.querySelectorAll('.section.side').forEach(e => {
    e.classList.remove('active');
  });
  if (l !== 'launcher') {
    document.querySelector(`.section.side.${l}`).classList.add('active');
    window.location.hash = `/s/${l}`;
  } else if (!r) {
    navigateRoot();
  }
}

function navigateTopbar (l, r) {
  if (l === 'installations') {
    return notify('SORRY!', 'This feature has not been added yet!', 2000);
  }
  document.querySelectorAll('.topbar .topbar-buttons a').forEach(e => {
    e.classList.remove('active');
  });
  document.querySelector(`.topbar .topbar-buttons #topbar-${l}`).classList.add('active');
  document.querySelectorAll('.section.top').forEach(e => {
    e.classList.remove('active');
  });
  if (l !== 'play') {
    document.querySelector(`.section.top.${l}`).classList.add('active');
    window.location.hash = `/t/${l}`;
  } else if (!r) {
    navigateRoot();
  }
}

function navigateRoot () {
  navigateSidebar('launcher', true);
  navigateTopbar('play', true);
  history.replaceState('', document.title, window.location.pathname + window.location.search);
}

function refreshInstalls () {
  data.custom.stored = localStorage.getItem('customVersions');
  if (typeof data.custom.stored === 'string') {
    try {
      data.custom.data = JSON.parse(data.custom.stored);
    } catch {
      data.custom.data = [];
    }
  } else {
    data.custom.data = [];
  }

  document.querySelectorAll('.custom-install').forEach(e => {
    e.remove();
  });

  data.custom.data.data.forEach(v => {
    addDropdown({
      ...v,
      custom: true
    });
  });
}

function addCustomVersion (data1) {
  data.custom.data.push(data1);
  localStorage.setItem('customVersions', JSON.stringify(data.custom));
}

function removeCustomVersion (id) {
  data.custom = data.custom.filter(v => v.id !== id);
  localStorage.setItem('customVersions', JSON.stringify(data.custom));
}

function notify (title, msg, time = 0) {
  function rmNotif (e) {
    e.classList.add('removed');
    setTimeout(() => {
      e.remove();
    }, 500);
  }

  const elm1 = document.createElement('h3');
  elm1.textContent = title;

  const elm2 = document.createElement('a');
  elm2.textContent = msg;

  const elm3 = document.createElement('div');
  elm3.classList.add('notif');

  elm3.appendChild(elm1);
  elm3.appendChild(elm2);
  document.querySelector('.notification-container').appendChild(elm3);

  elm3.addEventListener('click', () => {
    rmNotif(elm3);
  });

  if (time && time !== 0) {
    setTimeout(() => {
      rmNotif(elm3);
    }, time);
  }
}

function merge (t, s) {
  for (const key in s) {
    if (s[key] && typeof s[key] === 'object' && !Array.isArray(s[key])) {
      if (!t[key] || typeof t[key] !== 'object') t[key] = {};
      merge(t[key], s[key]);
    } else {
      t[key] = s[key];
    }
  }
  return t;
}

async function fetchChangelog () {
  let r = await fetch('api/changelog');
  r = await r.json();

  const cont = document.querySelector('.section.changelog .changelog');

  for (const [r1, v] of Object.entries(r)) {
    const elm = document.createElement('div');
    elm.classList.add('changelog-major');

    for (const [v1, c] of Object.entries(v.data)) {
      const elm1 = document.createElement('div');
      elm1.classList.add('changelog-minor');

      const elm2 = document.createElement('h2');
      elm2.textContent = v1;

      const elm3 = document.createElement('a');
      elm3.classList.add('changelog-date');
      elm3.textContent = `Released: ${c.date || 'Unknown'}`;

      const elm4 = document.createElement('ul');

      c.log.forEach(c1 => {
        const elm5 = document.createElement('li');
        let text = c1;
        if (c1.startsWith('!')) {
          text = text.substring(1);
          elm5.classList.add('indented');
        }
        elm5.textContent = text;
        elm4.appendChild(elm5);
      });

      elm1.appendChild(elm2);
      elm1.appendChild(elm3);
      elm1.appendChild(elm4);
      elm.appendChild(elm1);
    }

    cont.appendChild(elm);
  }
}