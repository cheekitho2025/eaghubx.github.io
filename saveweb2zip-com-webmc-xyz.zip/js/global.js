window.socketBase = (window.location.protocol == 'https:' ? 'wss:' : 'ws:') + '//' + window.location.host + window.location.pathname;

window.randomUsername = function () {
  const defaultNames = [
    'Yeeish',
    'Yeeish',
    'Yee',
    'Yee',
    'Yeer',
    'Yeeler',
    'Eagler',
    'Eagl',
    'Darver',
    'Darvler',
    'Vool',
    'Vigg',
    'Vigg',
    'Deev',
    'Yigg',
    'Yeeg'
  ];

  let username;
  do {
    const p1 = defaultNames[Math.floor(Math.random() * defaultNames.length)];
    const p2 = defaultNames[Math.floor(Math.random() * defaultNames.length)];
    const num = Math.floor(Math.random() * 10000).toString().padStart(4, '0');

    username = `${p1}${p2}${num}`;
  } while (username.length > 16);

  return username;
};

window.connectSocket = function (url, onmessage) {
  let ws;

  function start () {
    ws = new WebSocket(url);

    ws.onmessage = onmessage;

    ws.onclose = () => {
      setTimeout(start, 5000);
    };

    ws.onerror = () => {
      ws.close();
    };
  }

  start();
  return {
    send (data) {
      const payload = (typeof data === 'string') ? data : JSON.stringify(data);
      if (ws && ws.readyState === WebSocket.OPEN) ws.send(payload);
      else ws.send(payload);
    },
    close () {
      if (ws) try { ws.close(); } catch {}
    },
    getSocket () { return ws; },
    isOpen () { return !!ws && ws.readyState === WebSocket.OPEN; }
  };
};

window.connectPlayerCounter = function () {
  const ws = window.connectSocket(window.socketBase + 'api/playerCounter', (e) => {
    if (JSON.parse(e.data).type == 'ping') {
      ws.send(JSON.stringify({ type: 'pong' }));
    }
  });
  return ws;
};

window.getTime = function () {
  return new Intl.DateTimeFormat(undefined, {
    hour: 'numeric',
    minute: 'numeric',
    second: 'numeric',
    hour12: (new Intl.DateTimeFormat(undefined, { hour: 'numeric' })
      .formatToParts(new Date())
      .some(p => p.type === 'dayPeriod'))
  }).format(new Date());
};

if (!window.crypto?.randomUUID) {
  crypto.randomUUID = function () {
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
      const r = Math.random() * 16 | 0;
      const v = c === 'x' ? r : (r & 0x3 | 0x8);
      return v.toString(16);
    });
  };
}