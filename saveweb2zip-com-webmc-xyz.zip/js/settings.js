let settings;
const defaultSettings = {
  enableAnalytics: {
    name: 'Enable Analytics',
    desc: 'Toggle anonymous analytic collection',
    value: true,
    reloadRequired: true
  },
  showGameLog: {
    name: 'Show Game Log',
    desc: 'Automatically open the game console when launching',
    value: false,
    reloadRequired: false
  },
  wispcraft: {
    name: 'Wispcraft',
    desc: 'Automatically injects wispcraft into supported clients.',
    value: false,
    reloadRequired: false
  },
  showJSClients: {
    name: 'Show Javascript Clients',
    desc: 'Always shows javascript clients, even when WASM is available.',
    value: false,
    reloadRequired: true
  },
  gameNotifications: {
    name: 'Game Notifications',
    desc: 'Game launch & error notifications',
    value: true,
    reloadRequired: false
  },
  popupTab: {
    name: 'Popup in tab',
    desc: 'Opens the game in a new tab instead of a popup window',
    value: false,
    reloadRequired: false
  },
  globalPlayerCount: {
    name: 'Global Player Count',
    desc: 'Displays the count of all players across supported eaglercraft websites',
    value: false,
    reloadRequired: false
  },
  background: {
    name: 'Custom Background',
    desc: "Changes the launcher's main background",
    value: '',
    placeholder: 'https://example.com/background.png',
    reloadRequired: true
  }
};

const key = 'webmc-settings';

async function saveSettings () {
  localStorage.setItem(key, JSON.stringify(settings));
}

async function loadSettings () {
  try {
    let stored = JSON.parse(localStorage.getItem(key));
    if (!stored) stored = {};

    settings = {};

    for (const key in defaultSettings) {
      settings[key] = {
        name: defaultSettings[key].name,
        value: key in stored ? stored[key].value : defaultSettings[key].value
      };
    }

    await saveSettings();
  } catch {
    settings = defaultSettings;
    await saveSettings();
  }
}

function initSettings () {
  const container = document.querySelector('.settings');

  for (const key in defaultSettings) {
    const def = defaultSettings[key];
    const val = settings[key].value;
    const label = document.createElement('label');

    let e;

    if (typeof def.value === 'boolean') {
      e = document.createElement('input');
      e.type = 'checkbox';
      e.checked = val;

      e.addEventListener('change', function () {
        settings[key].value = this.checked;
        saveSettings();
      });

      label.appendChild(e);
      label.appendChild(document.createTextNode(' ' + def.name));
    } else if (typeof def.value === 'string') {
      e = document.createElement('input');
      e.type = 'text';
      e.value = val;
      e.placeholder = def.placeholder;

      e.addEventListener('input', function () {
        settings[key].value = this.value;
        saveSettings();
      });

      label.appendChild(document.createTextNode(' ' + def.name));
      label.appendChild(e);
    }

    const desc = document.createElement('p');
    desc.textContent = def.desc;

    const div = document.createElement('div');
    div.classList.add('setting');
    div.classList.add(key);

    div.appendChild(label);
    div.appendChild(desc);
    container.appendChild(div);
  }
}
